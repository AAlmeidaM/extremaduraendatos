# CHANGELOG — Extremadura en Datos

## 2026-08-28 (2)

- **Parseo verificado y corregido contra la API real del INE** (no solo
  documentación): se descargó JSON real de 3 tablas — 50913 (IPC, CCAA),
  3996 (EPA paro, provincia) y 6150 (Compraventa vivienda, CCAA y provincia
  mezclados) — y se ejecutó `parsear_tabla()` contra ellas. Esto reveló
  varios campos mal asumidos:
  - `Fecha` es un string ISO 8601 con offset, no epoch en milisegundos
    (`datetime.fromtimestamp` habría petado). Ahora se usa
    `datetime.fromisoformat`.
  - Unidad/escala/tipo de dato van en `T3_Unidad`/`T3_Escala`/`T3_TipoDato`
    (strings simples), no en `Unidad`/`Escala`/`TipoDato` ni como
    `{"Nombre": ...}`.
  - El territorio se resuelve ahora primero vía el array `MetaData` de cada
    serie (`T3_Variable: "Comunidades y Ciudades Autónomas"` / `"Provincias"`),
    mucho más fiable que la subcadena en `Nombre` (que se mantiene como
    respaldo si una tabla no trae MetaData reconocible).
  - `T3_Periodo` (p.ej. "M12", "T4") se usa tal cual si el INE lo da, en vez
    de derivarlo siempre de la fecha.
  - Se eliminó `FIELD_MAP` (ya no hacía falta con nombres de campo reales
    confirmados); el punto único de ajuste sigue siendo `parse.py`.
- **Nuevo:** `serie.atributos` (JSONB, con índice GIN) — guarda el resto de
  dimensiones de cada serie (rubro, sexo, tipo/régimen de vivienda...) tal y
  como las da `MetaData`, ya separadas del territorio. Permite filtrar/agrupar
  por esas dimensiones sin volver a parsear `nombre_origen`. `db.py` y
  `sql/001_schema.sql` actualizados; la columna se añade también con
  `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` por si el esquema ya estaba
  aplicado.
- **Nuevo modo de carga histórica:** `ingest.py --modo historico` pide TODO
  el histórico de cada tabla (`nult` sin límite) en vez de los últimos
  periodos; pensado para la carga inicial de cada fuente. El modo por
  defecto (`incremental`, el que usa la tarea diaria) no cambia.
- Tests (`tests/test_parse.py`) reescritos con fixtures que reproducen la
  estructura real (antes eran inventados con nombres de campo equivocados);
  añadidas pruebas para el respaldo por subcadena, para `serie.atributos`, y
  para el caso "sin match" en tablas provinciales.
- Documentación (`docs/fuentes-ine.md`, `PROJECT.md`) actualizada: ya no dice
  "no verificado contra la API real" — documenta qué se verificó, cómo, y qué
  queda pendiente (verificar las 21 tablas restantes una por una si dan
  problemas).

## 2026-08-28

- El usuario aportó `Datos_Extremadura_Mensual.xlsx` con 21 fuentes del INE
  (Precios, Industria y Empresa, Turismo, Vivienda, Empleo). Añadidas al
  catálogo (`src\extremadura_datos\indicadores.py`), sustituyendo la tabla
  72989 (EPA por provincia, provisional) por la 3996 del Excel.
- **Cambio de modelo de datos:** añadida la tabla `serie` entre `indicador` y
  `observacion` (ver `sql/001_schema.sql` y `docs\fuentes-ine.md`). Motivo:
  varias de las tablas nuevas (IPC, turismo, industria) tienen muchas series
  por territorio y periodo (por rubro, tipo de alojamiento, sector...), y el
  modelo anterior las hubiera colapsado en una sola fila. Cambio hecho
  reescribiendo el esquema directamente (el proyecto aún no se había
  desplegado, sin datos que migrar).
- Añadida vista `v_observacion` para consultar todo unido en una fila.
- `db.py`: `get_or_create_serie`, `upsert_observaciones` ahora resuelve
  serie antes de volcar. `parse.py`: captura también el código de serie del
  INE (`COD`) cuando está presente.
- Test nuevo (`test_varias_series_mismo_territorio_y_periodo_no_se_pierden`)
  que fija en la suite el caso que motivó el cambio.
- Catálogo total: 24 indicadores (antes 4).

## 2026-08-26

- Creación del proyecto. Fase 1: ingesta + base de datos (sin API todavía).
- Esquema inicial en PostgreSQL (`fuente`, `territorio`, `indicador`,
  `observacion`, `carga_log`), pensado para admitir varias fuentes.
- Ingesta de 4 tablas del INE (EPA y Contabilidad Regional de España, a nivel
  CCAA y provincial), filtradas a Extremadura/Badajoz/Cáceres.
- `scripts\setup.ps1` (entorno, base de datos, esquema, Git, tarea programada
  diaria) y `scripts\run_ingesta.ps1` (ejecución + log).
- Pendiente: el usuario ejecute `scripts\setup.ps1` en el PC y verifique con
  `inspect_table.py` que el parseo del JSON del INE coincide con la
  respuesta real (no se pudo probar en el entorno donde se generó este
  proyecto — ver `PROJECT.md` §17).
